import turtle
import winsound

#Space = Bass Drum
#F = Snare
#E = Crash 1
#S = Tom 1

#J = HiHat
#I = Crash 2
#L = Tom 2

#Window information
wn = turtle.Screen()
wn.title = ("DrumSet by Arani")
wn.bgcolor("black")
wn.setup(width=1000, height=600)
wn.tracer(0)


#Lines
line_1 = turtle.Turtle()
line_1.speed(0)
line_1.shape("square") #By default its 20x20 pixels
line_1.shapesize(stretch_wid=15, stretch_len=.5)
line_1.color("grey")
line_1.penup()
line_1.goto(-350,-175)

line_2 = turtle.Turtle()
line_2.speed(0)
line_2.shape("square") #By default its 20x20 pixels
line_2.shapesize(stretch_wid=10, stretch_len=.5)
line_2.color("grey")
line_2.penup()
line_2.goto(-200,-275)

line_3 = turtle.Turtle()
line_3.speed(0)
line_3.shape("square") #By default its 20x20 pixels
line_3.shapesize(stretch_wid=25, stretch_len=.5)
line_3.color("grey")
line_3.penup()
line_3.goto(-150,-150)

line_4 = turtle.Turtle()
line_4.speed(0)
line_4.shape("square") #By default its 20x20 pixels
line_4.shapesize(stretch_wid=10, stretch_len=.5)
line_4.color("grey")
line_4.penup()
line_4.goto(-75,-175)

line_5 = turtle.Turtle()
line_5.speed(0)
line_5.shape("square") #By default its 20x20 pixels
line_5.shapesize(stretch_wid=10, stretch_len=.5)
line_5.color("grey")
line_5.penup()
line_5.goto(150,-200)

line_6 = turtle.Turtle()
line_6.speed(0)
line_6.shape("square") #By default its 20x20 pixels
line_6.shapesize(stretch_wid=25, stretch_len=.5)
line_6.color("grey")
line_6.penup()
line_6.goto(275,-250)    

#Bass Drum
bass_drum = turtle.Turtle()
bass_drum.speed(0)
bass_drum.shape("circle") #By default its 20x20 pixels
bass_drum.shapesize(stretch_wid=14, stretch_len=14)
bass_drum.color("brown")
bass_drum.penup()
bass_drum.goto(0,-300)

bass_drumint = turtle.Turtle()
bass_drumint.speed(0)
bass_drumint.shape("circle") #By default its 20x20 pixels
bass_drumint.shapesize(stretch_wid=13, stretch_len=13)
bass_drumint.color("white")
bass_drumint.penup()
bass_drumint.goto(0,-300)


#Snare
snare_drum = turtle.Turtle()
snare_drum.speed(0)
snare_drum.shape("circle") #By default its 20x20 pixels
snare_drum.shapesize(stretch_wid=6, stretch_len=8)
snare_drum.color("brown")
snare_drum.penup()
snare_drum.goto(-200,-175)

snare_drumint = turtle.Turtle()
snare_drumint.speed(0)
snare_drumint.shape("circle") #By default its 20x20 pixels
snare_drumint.shapesize(stretch_wid=5.5, stretch_len=7)
snare_drumint.color("white")
snare_drumint.penup()
snare_drumint.goto(-200,-175)


#Tom1
tom1_drum = turtle.Turtle()
tom1_drum.speed(0)
tom1_drum.shape("circle") #By default its 20x20 pixels
tom1_drum.shapesize(stretch_wid=8, stretch_len=9)
tom1_drum.color("brown")
tom1_drum.penup()
tom1_drum.goto(-75,-75)

tom1_drumint = turtle.Turtle()
tom1_drumint.speed(0)
tom1_drumint.shape("circle") #By default its 20x20 pixels
tom1_drumint.shapesize(stretch_wid=7, stretch_len=8)
tom1_drumint.color("white")
tom1_drumint.penup()
tom1_drumint.goto(-75,-75)


#Tom2
tom2_drum = turtle.Turtle()
tom2_drum.speed(0)
tom2_drum.shape("circle") #By default its 20x20 pixels
tom2_drum.shapesize(stretch_wid=8, stretch_len=9)
tom2_drum.color("brown")
tom2_drum.penup()
tom2_drum.goto(150,-100)

tom2_drumint = turtle.Turtle()
tom2_drumint.speed(0)
tom2_drumint.shape("circle") #By default its 20x20 pixels
tom2_drumint.shapesize(stretch_wid=7, stretch_len=8)
tom2_drumint.color("white")
tom2_drumint.penup()
tom2_drumint.goto(150,-100)


#Hihat
hihat_drumint = turtle.Turtle()
hihat_drumint.speed(0)
hihat_drumint.shape("circle") #By default its 20x20 pixels
hihat_drumint.shapesize(stretch_wid=4, stretch_len=8)
hihat_drumint.color("yellow")
hihat_drumint.penup()
hihat_drumint.goto(-350,-50)

hihat_drum = turtle.Turtle()
hihat_drum.speed(0)
hihat_drum.shape("circle") #By default its 20x20 pixels
hihat_drum.shapesize(stretch_wid=.50, stretch_len=1)
hihat_drum.color("white")
hihat_drum.penup()
hihat_drum.goto(-350,-50)


#Crash1
crash1_drumint = turtle.Turtle()
crash1_drumint.speed(0)
crash1_drumint.shape("circle") #By default its 20x20 pixels
crash1_drumint.shapesize(stretch_wid=4, stretch_len=9.5)
crash1_drumint.color("yellow")
crash1_drumint.penup()
crash1_drumint.goto(-150,100)

crash1_drum = turtle.Turtle()
crash1_drum.speed(0)
crash1_drum.shape("circle") #By default its 20x20 pixels
crash1_drum.shapesize(stretch_wid=.50, stretch_len=1)
crash1_drum.color("white")
crash1_drum.penup()
crash1_drum.goto(-150,100)


#Crash2
crash2_drumint = turtle.Turtle()
crash2_drumint.speed(0)
crash2_drumint.shape("circle") #By default its 20x20 pixels
crash2_drumint.shapesize(stretch_wid=4, stretch_len=9.5)
crash2_drumint.color("yellow")
crash2_drumint.penup()
crash2_drumint.goto(275,0)

crash2_drum = turtle.Turtle()
crash2_drum.speed(0)
crash2_drum.shape("circle") #By default its 20x20 pixels
crash2_drum.shapesize(stretch_wid=.50, stretch_len=1)
crash2_drum.color("white")
crash2_drum.penup()
crash2_drum.goto(275,0)




#Hit and Release Fuctions


def bassdrumhit():
    bass_drumint.color("black")
    winsound.PlaySound("bassdrum_Master.wav", winsound.SND_ASYNC)
def bassdrumrel():
    bass_drumint.color("white")

def snaredrumhit():
    snare_drumint.color("red")
    winsound.PlaySound("snarehit_Master.wav", winsound.SND_ASYNC)
def snaredrumrel():
    snare_drumint.color("white")


def tom1hit():
    tom1_drumint.color("red")
    winsound.PlaySound("tom1hit_Master.wav", winsound.SND_ASYNC)
def tom1rel():
    tom1_drumint.color("white")


def tom2hit():
    tom2_drumint.color("red")
    winsound.PlaySound("tom2hit_Master.wav", winsound.SND_ASYNC)
def tom2rel():
    tom2_drumint.color("white")

def hihathit():
    hihat_drumint.color("black")
    winsound.PlaySound("hihathit_Master.wav", winsound.SND_ASYNC)
def hihatrel():
    hihat_drumint.color("yellow")


def crash1hit():
    crash1_drumint.color("black")
    winsound.PlaySound("crash1hit_Master.wav", winsound.SND_ASYNC)
def crash1rel():
    crash1_drumint.color("yellow")

def crash2hit():
    crash2_drumint.color("black")
    winsound.PlaySound("crash2hit_Master.wav", winsound.SND_ASYNC)
def crash2rel():
    crash2_drumint.color("yellow")

#Keyboard Input
wn.listen()

wn.onkeypress(bassdrumhit, 'space')
wn.onkeyrelease(bassdrumrel, 'space')

wn.onkeypress(snaredrumhit, 'f')
wn.onkeyrelease(snaredrumrel, 'f')

wn.onkeypress(tom1hit, 's')
wn.onkeyrelease(tom1rel, 's')

wn.onkeypress(tom2hit, 'l')
wn.onkeyrelease(tom2rel, 'l')

wn.onkeypress(hihathit, 'j')
wn.onkeyrelease(hihatrel, 'j')

wn.onkeypress(crash1hit, 'e')
wn.onkeyrelease(crash1rel, 'e')

wn.onkeypress(crash2hit, 'i')
wn.onkeyrelease(crash2rel, 'i')

# Main (Keep Under the objects)
while True:
    wn.update()
