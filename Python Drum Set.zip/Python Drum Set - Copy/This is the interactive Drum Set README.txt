This is the interactive Drum Set made with Python/Turtle

CONTROLS

Space = Bass Drum
F = Snare
E = Crash 1
S = Tom 1

J = Hihat
I = Crash 2
L = Tom 2

KNOWN ISSUES

Uses winsound and wav files to play sounds and because of that sounds cannot be played simultaneously.
- Using 2 flags for the play sound command doesn't bypass this.
- Turtle doesn't let the onkeypress command have 2 inputs so a combination sound isnt possible.
- Using different keybinds for a combination sound isn't practical.

To solve, will be creating a pygame version with a different way to play sound.
